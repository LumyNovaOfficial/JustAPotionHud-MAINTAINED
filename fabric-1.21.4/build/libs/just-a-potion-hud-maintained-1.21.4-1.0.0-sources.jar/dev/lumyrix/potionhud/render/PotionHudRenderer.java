package dev.lumyrix.potionhud.render;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.lumyrix.potionhud.config.PotionHudConfig;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.class_1058;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1921;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_6880;
import net.minecraft.class_9779;

public final class PotionHudRenderer {
    private static final int BASE_ICON    = 18;
    private static final int BASE_PAD     = 4;
    private static final int COLOR_WARN   = 0xFFDD4949;
    private static final int FLICKER_START = 119;

    private PotionHudRenderer() {}

    public static void render(class_332 graphics, class_9779 delta) {
        PotionHudConfig cfg = PotionHudConfig.getInstance();
        if (!cfg.isEnabled()) return;

        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) return;

        List<class_1293> effects = new ArrayList<>(client.field_1724.method_6026());
        if (effects.isEmpty()) return;

        effects.sort(Comparator.comparingInt(class_1293::method_5584));

        float scale  = cfg.getScale();
        int iconSize = Math.max(1, (int)(BASE_ICON * scale));
        int pad      = Math.max(1, (int)(BASE_PAD  * scale));

        int screenW = client.method_22683().method_4486();
        int screenH = client.method_22683().method_4502();
        int x = (int)(cfg.getXFrac() * screenW);
        int y = (int)(cfg.getYFrac() * screenH);

        for (class_1293 inst : effects) {
            class_6880<class_1291> holder = inst.method_5579();
            class_1291 effect = holder.comp_349();

            String name = effect.method_5560().getString() + romanLevel(inst.method_5578());
            String time = formatTicks(inst.method_5584());

            int ticks     = inst.method_5584();
            boolean isWarn    = ticks != Integer.MAX_VALUE && ticks <= 319;
            boolean isFlicker = cfg.isFlicker() && ticks != Integer.MAX_VALUE && ticks <= FLICKER_START;

            float alpha = 1.0f;
            if (isFlicker) {
                int elapsed = FLICKER_START - ticks;
                float periodTicks = ticks > 60 ? 8f : ticks > 40 ? 8f / 1.25f : (8f / 1.25f) / 1.05f;
                alpha = 0.15f + 0.85f * (float)(0.5 + 0.5 * Math.cos(2 * Math.PI * elapsed / periodTicks));
            }

            int timeColor = isWarn ? ((int)(alpha * 255) << 24 | (COLOR_WARN & 0x00FFFFFF)) : 0xFFFFFFFF;
            int nameColor = isFlicker ? ((int)(alpha * 255) << 24 | 0x00FFFFFF) : 0xFFFFFFFF;

            final int fx = x, fy = y, fSize = iconSize;
            class_1058 sprite = client.method_18505().method_18663(holder);
            graphics.method_51452();
            RenderSystem.setShaderColor(1f, 1f, 1f, alpha);
            graphics.method_52709(class_1921::method_62277, sprite, fx, fy, fSize, fSize);
            graphics.method_51452();
            RenderSystem.setShaderColor(1f, 1f, 1f, 1f);

            int textX = x + iconSize + pad;
            int lineH  = client.field_1772.field_2000 + 1;
            int textY  = y + (iconSize - lineH * 2) / 2;

            graphics.method_51448().method_22903();
            graphics.method_51448().method_46416((float) textX, (float) textY, 0.0f);
            graphics.method_51448().method_22905(scale, scale, 1.0f);
            graphics.method_51433(client.field_1772, name, 0, 0,     nameColor, false);
            graphics.method_51433(client.field_1772, time, 0, lineH, timeColor,  false);
            graphics.method_51448().method_22909();

            y += iconSize + pad;
        }
    }

    private static String formatTicks(int ticks) {
        if (ticks == Integer.MAX_VALUE) return "**:**";
        int s = ticks / 20;
        return String.format("%d:%02d", s / 60, s % 60);
    }

    private static String romanLevel(int amp) {
        return switch (amp) {
            case 0  -> "";
            case 1  -> " II";
            case 2  -> " III";
            case 3  -> " IV";
            case 4  -> " V";
            default -> " " + (amp + 1);
        };
    }
}
