/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.api.renderer.v1.model;

import java.util.List;
import java.util.function.Supplier;
import net.fabricmc.fabric.api.renderer.v1.render.RenderContext;
import net.minecraft.class_806;
import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.client.renderer.block.model.BlockStateModel;
import net.minecraft.client.renderer.block.model.ItemTransforms;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockAndTintGetter;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Base class for specialized model implementations that need to wrap other baked models.
 * Avoids boilerplate code for pass-through methods.
 */
public abstract class ForwardingBakedModel implements BlockStateModel, WrapperBakedModel {
	/** implementations must set this somehow. */
	protected BlockStateModel wrapped;

	@Override
	public boolean isVanillaAdapter() {
		return wrapped.isVanillaAdapter();
	}

	@Override
	public void emitBlockQuads(BlockAndTintGetter blockView, BlockState state, BlockPos pos, Supplier<RandomSource> randomSupplier, RenderContext context) {
		wrapped.emitBlockQuads(blockView, state, pos, randomSupplier, context);
	}

	@Override
	public void emitItemQuads(ItemStack stack, Supplier<RandomSource> randomSupplier, RenderContext context) {
		wrapped.emitItemQuads(stack, randomSupplier, context);
	}

	@Override
	public List<BakedQuad> method_4707(BlockState blockState, Direction face, RandomSource rand) {
		return wrapped.method_4707(blockState, face, rand);
	}

	@Override
	public boolean method_4708() {
		return wrapped.method_4708();
	}

	@Override
	public boolean method_4712() {
		return wrapped.method_4712();
	}

	@Override
	public boolean method_4713() {
		return wrapped.method_4713();
	}

	@Override
	public TextureAtlasSprite method_4711() {
		return wrapped.method_4711();
	}

	@Override
	public boolean method_24304() {
		return wrapped.method_24304();
	}

	@Override
	public ItemTransforms method_4709() {
		return wrapped.method_4709();
	}

	@Override
	public class_806 method_4710() {
		return wrapped.method_4710();
	}

	@Override
	public BlockStateModel getWrappedModel() {
		return wrapped;
	}
}
