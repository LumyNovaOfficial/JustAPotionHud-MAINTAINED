package dev.lumyrix.potionhud.screen;

import dev.lumyrix.potionhud.config.PotionHudConfig;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_357;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class PotionHudConfigScreen extends class_437 {

    private final class_437 parent;
    private static final int W = 200;
    private static final int H = 20;

    public PotionHudConfigScreen(class_437 parent) {
        super(class_2561.method_43470("Potion HUD Config"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        PotionHudConfig cfg = PotionHudConfig.getInstance();
        int cx = this.field_22789 / 2 - W / 2;
        int cy = this.field_22790 / 2 - 75;

        method_37063(new class_357(cx, cy, W, H,
                scaleLabel(cfg.getScale()), (cfg.getScale() - 0.5f) / 1.5f) {
            @Override protected void method_25346() { method_25355(scaleLabel(toScale(this.field_22753))); }
            @Override protected void method_25344()    { PotionHudConfig.getInstance().setScale(toScale(this.field_22753)); }
        });

        method_37063(class_4185.method_46430(
                class_2561.method_43470(cfg.isEnabled() ? "Enabled" : "Disabled"),
                btn -> {
                    boolean now = !PotionHudConfig.getInstance().isEnabled();
                    PotionHudConfig.getInstance().setEnabled(now);
                    btn.method_25355(class_2561.method_43470(now ? "Enabled" : "Disabled"));
                }).method_46433(cx, cy + 25).method_46437(W, H).method_46431());

        method_37063(new class_357(cx, cy + 50, W, H,
                xLabel(cfg.getXFrac()), cfg.getXFrac()) {
            @Override protected void method_25346() { method_25355(xLabel((float) this.field_22753)); }
            @Override protected void method_25344()    { PotionHudConfig.getInstance().setXFrac((float) this.field_22753); }
        });

        method_37063(new class_357(cx, cy + 75, W, H,
                yLabel(cfg.getYFrac()), cfg.getYFrac()) {
            @Override protected void method_25346() { method_25355(yLabel((float) this.field_22753)); }
            @Override protected void method_25344()    { PotionHudConfig.getInstance().setYFrac((float) this.field_22753); }
        });

        method_37063(class_4185.method_46430(
                class_2561.method_43470("Flicker <6s: " + (cfg.isFlicker() ? "ON" : "OFF")),
                btn -> {
                    boolean now = !PotionHudConfig.getInstance().isFlicker();
                    PotionHudConfig.getInstance().setFlicker(now);
                    btn.method_25355(class_2561.method_43470("Flicker <6s: " + (now ? "ON" : "OFF")));
                }).method_46433(cx, cy + 100).method_46437(W, H).method_46431());

        method_37063(class_4185.method_46430(
                class_2561.method_43470("Reset to Defaults"),
                btn -> {
                    PotionHudConfig.getInstance().resetToDefaults();
                    PotionHudConfig.save();
                    assert this.field_22787 != null;
                    this.field_22787.method_1507(new PotionHudConfigScreen(this.parent));
                }).method_46433(cx, cy + 130).method_46437(W, H).method_46431());

        method_37063(class_4185.method_46430(
                class_2561.method_43471("gui.done"),
                btn -> this.method_25419())
                .method_46433(cx, cy + 155).method_46437(W, H).method_46431());
    }

    private static float toScale(double v) { return Math.round((0.5f + (float)v * 1.5f) * 100) / 100.0f; }
    private static class_2561 scaleLabel(float s) { return class_2561.method_43470("Scale: " + String.format("%.2f", s)); }
    private static class_2561 xLabel(float v) { return class_2561.method_43470("X: " + String.format("%.0f%%", v * 100)); }
    private static class_2561 yLabel(float v) { return class_2561.method_43470("Y: " + String.format("%.0f%%", v * 100)); }

    @Override
    public void method_25419() {
        PotionHudConfig.save();
        assert this.field_22787 != null;
        this.field_22787.method_1507(parent);
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        super.method_25394(graphics, mouseX, mouseY, partialTick);
        graphics.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, this.field_22790 / 2 - 95, 0xFFFFFFFF);
    }
}
