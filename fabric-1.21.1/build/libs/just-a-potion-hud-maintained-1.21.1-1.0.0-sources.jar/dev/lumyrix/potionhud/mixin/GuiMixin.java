package dev.lumyrix.potionhud.mixin;

import net.minecraft.class_329;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_329.class)
public class GuiMixin {
    @Inject(method = "renderEffects", at = @At("HEAD"), require = 0)
    private void potionhud$noOp(CallbackInfo ci) {
    }
}
