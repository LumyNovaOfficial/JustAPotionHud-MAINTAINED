package dev.lumyrix.potionhud.mixin;

import dev.lumyrix.potionhud.screen.PotionHudConfigScreen;
import net.minecraft.class_2561;
import net.minecraft.class_4185;
import net.minecraft.class_433;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_433.class)
public class PauseScreenMixin extends net.minecraft.class_437 {

    protected PauseScreenMixin() {
        super(class_2561.method_43473());
    }

    @Inject(method = "init", at = @At("TAIL"))
    private void potionhud$addConfigButton(CallbackInfo ci) {
        this.method_37063(class_4185.method_46430(
                class_2561.method_43470("Potion HUD"),
                btn -> {
                    assert this.field_22787 != null;
                    this.field_22787.method_1507(new PotionHudConfigScreen(this));
                })
                .method_46433(this.field_22789 - 106, 6)
                .method_46437(100, 16)
                .method_46431());
    }
}
